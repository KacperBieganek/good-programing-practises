class Shape(object):
    shape = ""

    def __init__(self):
        self.shape = "shape"

    def circuit(self):
        pass
