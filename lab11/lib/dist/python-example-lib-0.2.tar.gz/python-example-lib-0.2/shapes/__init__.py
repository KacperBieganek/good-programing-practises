from .shape import *
from .circle import *
from .square import *
from .triangle import *
